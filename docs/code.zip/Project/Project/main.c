/* Includes ------------------------------------------------------------------*/
#include <math.h>
#include <stdio.h>
#include "stm32f10x_conf.h"
#include "stm32f10x.h"
#include "lcd.h"
#include "stm32f10x_tim.h"
#include "stm32f10x_it.h"


uint32_t Base_Addr = 0x20000000;
/* Private typedef -----------------------------------------------------------*/
GPIO_InitTypeDef GPIO_InitStructure;
TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
TIM_OCInitTypeDef  TIM_OCInitStructure;
NVIC_InitTypeDef NVIC_InitStructure;
EXTI_InitTypeDef EXTI_InitStructure;

/** @addtogroup STM32F10x_StdPeriph_Examples
  * @{
  */

/** @addtogroup ADC_ADC1_DMA
  * @{
  */ 


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define ADC1_DR_Address    ((uint32_t)0x4001244C)
#define FFT_LENGTH      256
#define PI 3.14159265


/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
u8 *adcstr = ADCString;
ADC_InitTypeDef ADC_InitStructure;
DMA_InitTypeDef DMA_InitStructure;
ErrorStatus HSEStartUpStatus;
__IO uint16_t ADCConvertedValue;
uint32_t ADC_VAL[256];
uint32_t Timebase_uS[13] = {50, 100, 250, 500, 1000, 2500, 5000, 10000, 25000,
 50000, 100000, 250000, 500000};
uint16_t Pixel_VAL[256];
uint16_t Timebase_Set[] = {5, 11, 30, 61, 124, 309, 619, 1239, 3099, 6199, 12399, 30999, 61999 };
uint8_t Timebase_Ptr = 6;
uint16_t Voltbase_mV[8] = {20, 50, 100, 200, 500, 1000, 2000, 3000};
double Voltbase_Set[] = {3.103, 7.758, 15.515, 31.030, 77.576, 155.152, 310.303, 465.455 }; //ADClvl / unflipped pixel
uint8_t Voltbase_Ptr = 5;
uint8_t Measurement_Ptr = 0;
uint8_t Measurement_Cnt = 0;
uint16_t Attenuation_Signal = 0;
u32 fft_output[FFT_LENGTH];  
u32 test[256];


bool Measurement_isSwitched = FALSE;
bool AC_isSelected = FALSE;
bool Source_isAttenuated = FALSE;


//TODO: I have connected the variable resistor to PF7 and the attenuation switch to PF6
/*  findMax and findMin have a fatal error.  They find the highest and lowest point but to get frequency we really want 
    to find the local min and max.  */


    
/* Private function prototypes -----------------------------------------------*/
void RCC_Configuration(void);
void GPIO_Configuration(void);
void ADC_Configuration(void);
void TIM_Configuration(void);
//void DMA_Configuration(void);
void Interrupt_Configuration(void);
void DSO_Draw_Waveform(void);

void DSO_DrawHeader(void);
void DSO_DrawVoltTime(void);
void DSO_DrawFT(void);
void DSO_DrawMinMax(void);
void DSO_DrawRiseFall(void);
void DSO_DrawRMSMean(void);
void DSO_DrawPkPk(void);
uint8_t DSO_Pix_Find_Mid_Pt(void);
//u32* DSO_Compute_FFT(u32* samples);
//u16 DSO_Frequency(u32* sprectrum, u16 sampling_rate);


uint8_t DSO_Pix_Find_Max(uint8_t offset);
uint8_t DSO_Pix_Find_Min(uint8_t offset);


void DSO_Fill_Gap(uint8_t x1, uint8_t x2, uint8_t y);
void LongDelay(u32 nCount);  

/* Private functions ---------------------------------------------------------*/

/**
  * @brief   Main program
  * @param  None
  * @retval None
  */
int main(void)
{
  if (RCC->CSR & RCC_CSR_PORRSTF)
  {
     RCC->CSR |= RCC_CSR_RMVF;
     NVIC_SystemReset();
  }
    
  
  SystemInit();
  //NVIC_SystemReset();
  /* Enable FSMC, GPIOA, GPIOD, GPIOE, GPIOF, GPIOG and AFIO clocks */
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_FSMC, ENABLE);

  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOD | 
                         RCC_APB2Periph_GPIOE | RCC_APB2Periph_GPIOF | 
                         RCC_APB2Periph_GPIOG | RCC_APB2Periph_AFIO, ENABLE);
  
  STM3210E_LCD_Init(); 

  /* System clocks configuration ---------------------------------------------*/
  RCC_Configuration();

  /* GPIO configuration ------------------------------------------------------*/
  GPIO_Configuration();

  LCD_Clear();
  

  ADC_Configuration();
  TIM_Configuration();
  Interrupt_Configuration();
  
  if( GPIOF->IDR & GPIO_Pin_6 )
  {
    Source_isAttenuated = TRUE;
  }
  
  while (1)
  {
        
  }
}

/**
  * @brief  Configures the different system clocks.
  * @param  None
  * @retval None
  */
void RCC_Configuration(void)
{
    /* RCC system reset(for debug purpose) */
  RCC_DeInit();

  /* Enable HSE */
  RCC_HSEConfig(RCC_HSE_ON);

  /* Wait till HSE is ready */
  HSEStartUpStatus = RCC_WaitForHSEStartUp();

  if(HSEStartUpStatus == SUCCESS)
  { 
    /* HCLK = SYSCLK */
    RCC_HCLKConfig(RCC_SYSCLK_Div1); 
  
    /* PCLK2 = HCLK */
    RCC_PCLK2Config(RCC_HCLK_Div1); 

    /* PCLK1 = HCLK/2 */
    RCC_PCLK1Config(RCC_HCLK_Div2);

    /* ADCCLK = PCLK2/4 */
    RCC_ADCCLKConfig(RCC_PCLK2_Div4); 
  
#ifndef STM32F10X_CL  
    /* PLLCLK = 8MHz * 7 = 56 MHz */
    RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_7);

#else
    /* Configure PLLs *********************************************************/
    /* PLL2 configuration: PLL2CLK = (HSE / 5) * 8 = 40 MHz */
    RCC_PREDIV2Config(RCC_PREDIV2_Div5);
    RCC_PLL2Config(RCC_PLL2Mul_8);

    /* Enable PLL2 */
    RCC_PLL2Cmd(ENABLE);

    /* Wait till PLL2 is ready */
    while (RCC_GetFlagStatus(RCC_FLAG_PLL2RDY) == RESET)
    {}

    /* PLL configuration: PLLCLK = (PLL2 / 5) * 7 = 56 MHz */ 
    RCC_PREDIV1Config(RCC_PREDIV1_Source_PLL2, RCC_PREDIV1_Div5);
    RCC_PLLConfig(RCC_PLLSource_PREDIV1, RCC_PLLMul_7);
#endif

    /* Enable PLL */ 
    RCC_PLLCmd(ENABLE);

    /* Wait till PLL is ready */
    while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
    {
    }

    /* Select PLL as system clock source */
    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

    /* Wait till PLL is used as system clock source */
    while(RCC_GetSYSCLKSource() != 0x08)
    {
    }
  }

/* Enable peripheral clocks --------------------------------------------------*/
  /* Enable DMA1 clock */
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

  /* Enable ADC1 and GPIOC clock */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1 | RCC_APB2Periph_GPIOC, ENABLE);
}


/********************************************************* 
 *
 *    Init Configurations
 *
 *********************************************************/

/**
  * @brief  Configures the different GPIO ports.
  * @param  None
  * @retval None
  */
void GPIO_Configuration(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;

  /* Task 1 - Configure the INPUTS */

  /* Configure PC.04 (ADC Channel14) as analog input ------------*/
 
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOC, &GPIO_InitStructure);

  /* Configure B.11-15 joystick keys as inputs -------------------------*/
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  
  /* PF.06 will be used to detect attenuation change ----------------*/
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF, ENABLE);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_Init(GPIOF, &GPIO_InitStructure);
  
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF, ENABLE);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
  GPIO_Init(GPIOF, &GPIO_InitStructure);
  
  // LED indicators
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF, ENABLE);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_8;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOF, &GPIO_InitStructure);
  

}

void Interrupt_Configuration(void)
{
  GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource12);
  EXTI_InitStructure.EXTI_Line = EXTI_Line12;
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
  EXTI_Init(&EXTI_InitStructure);
    
  GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource11);
  EXTI_InitStructure.EXTI_Line = EXTI_Line11;
  EXTI_Init(&EXTI_InitStructure);
  
  GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource13);
  EXTI_InitStructure.EXTI_Line = EXTI_Line13;
  EXTI_Init(&EXTI_InitStructure);
  
  GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource14);
  EXTI_InitStructure.EXTI_Line = EXTI_Line14;
  EXTI_Init(&EXTI_InitStructure);
  
  GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource15);
  EXTI_InitStructure.EXTI_Line = EXTI_Line15;
  EXTI_Init(&EXTI_InitStructure);
  
  /* Attenuation Line Interrupt ----------------------------------------------*/
  GPIO_EXTILineConfig(GPIO_PortSourceGPIOF, GPIO_PinSource6);
  EXTI_InitStructure.EXTI_Line = EXTI_Line6;
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
  EXTI_Init(&EXTI_InitStructure);
  
  GPIO_EXTILineConfig(GPIO_PortSourceGPIOF, GPIO_PinSource7);
  EXTI_InitStructure.EXTI_Line = EXTI_Line7;
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
  EXTI_Init(&EXTI_InitStructure);
  
  
  NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  
  NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  
  NVIC->ISER[(TIM4_IRQn >> 5)] = (1 << (TIM4_IRQn & 0x1F));
  NVIC->ISER[(TIM3_IRQn >> 5)] = (1 << (TIM3_IRQn & 0x1F));

}

/**
 * @brief  Configures the ADC1 to continuously convert the waveform.
           Also enables ADC1 to trigger the DMA request
 * @param  None
 * @retval None
 */
void ADC_Configuration(void)
{
  
  ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
  ADC_InitStructure.ADC_ScanConvMode = DISABLE;
  ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
  ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
  ADC_InitStructure.ADC_NbrOfChannel = 1;
  ADC_Init(ADC1, &ADC_InitStructure);
  
  /* ADC1 regular channel14 configuration */ 
  ADC_RegularChannelConfig(ADC1, ADC_Channel_14, 1, ADC_SampleTime_1Cycles5);
  
  /* Enable ADC1 DMA */
  //ADC_DMACmd(ADC1, ENABLE);
  
  /* Enable ADC1 */
  ADC_Cmd(ADC1, ENABLE);
  
  /* Enable ADC1 reset calibration register */   
  ADC_ResetCalibration(ADC1);
  /* Check the end of ADC1 reset calibration register */
  while(ADC_GetResetCalibrationStatus(ADC1));
  
  /* Start ADC1 calibration */
  ADC_StartCalibration(ADC1);
  /* Check the end of ADC1 calibration */
  while(ADC_GetCalibrationStatus(ADC1));
  
  /* Start ADC1 Software Conversion */ 
  ADC_SoftwareStartConvCmd(ADC1, ENABLE);
}


/**
  * @brief  Configures TIM channel. PA.06, 10kHz Timer
  * @param  None
  * @retval None
  */
void TIM_Configuration(void)
{
  /*
  NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  */
  
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  //How to configure TIM3_CH1 as the alternate??


  TIM_TimeBaseStructure.TIM_Period = Timebase_Set[Timebase_Ptr]; //<- TIMx_ARR register
  //use clk division after prescaling
  TIM_TimeBaseStructure.TIM_Prescaler = 27;
  TIM_TimeBaseStructure.TIM_ClockDivision = 0;
  //
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);

  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_Pulse = 4;  //<- TIMx_CCRx register
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
  TIM_OC1Init(TIM3, &TIM_OCInitStructure);
  
  TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);
  TIM_Cmd(TIM3, ENABLE);
  
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
  
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  
  
  TIM_TimeBaseStructure.TIM_Period = 33332; //<- TIMx_ARR register
  //use clk division after prescaling
  TIM_TimeBaseStructure.TIM_Prescaler = 55;
  TIM_TimeBaseStructure.TIM_ClockDivision = 0;
  //
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);
  
  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_Pulse = 16000;  //<- TIMx_CCRx register
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
  TIM_OC1Init(TIM4, &TIM_OCInitStructure);
  
  TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);
  
  TIM_Cmd(TIM4, ENABLE);
  
  
   // NVIC->ISER[(TIM4_IRQn >> 5)] = (1 << (TIM4_IRQn & 0x1F));
 // NVIC->ISER[(TIM3_IRQn >> 5)] = (1 << (TIM3_IRQn & 0x1F));


 // NVIC_Enable(TIM3_IRQn);
  
  
  
  
  
  /* TEST SIGNAL FOR OSCILLOSCOPE REFINEMENTS */
  
  
  
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  //How to configure TIM3_CH1 as the alternate??


  TIM_TimeBaseStructure.TIM_Period = 55999; //<- TIMx_ARR register
  //use clk division after prescaling
  TIM_TimeBaseStructure.TIM_Prescaler = 0;
  TIM_TimeBaseStructure.TIM_ClockDivision = 0;
  //
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_Pulse = 28000;  //<- TIMx_CCRx register
  TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
  TIM_OC1Init(TIM2, &TIM_OCInitStructure);
  
  TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
  TIM_Cmd(TIM2, ENABLE);

}

#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif


/* DELAY  */

//void LongDelay(__IO uint32_t nCount)
void LongDelay(u32 nCount)
{
  for(; nCount != 0; nCount--);
}


void DMA_Configuration(void)
{
 /******CONFIGURE THE DMA TO PROCESS ONE TRANSFER PER ADC CONVERSION*******/

 //Upon receipt of the DMA_IT_HT we can start the first half processing
 //When DMA_IT_TC is issued then we will proceed to second half processing
 //and the refresh the screen

//enable DMA1 clock
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

//reset DMA1 channe1 to default values;
  DMA_DeInit(DMA1_Channel1);
  DMA_InitStructure.DMA_PeripheralBaseAddr = ADC1_DR_Address;
  DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t) &ADCConvertedValue;
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
  DMA_InitStructure.DMA_BufferSize = 1;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Disable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
  DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
  DMA_Init(DMA1_Channel1, &DMA_InitStructure);
    
  /* Enable DMA1 channel1 */
  DMA_Cmd(DMA1_Channel1, ENABLE);


}





/********************************************************* 
 *
 *    Interrupt Handlers
 *
 *********************************************************/
int ypos = 0;
int ypos_temp = 0;
int start_flag = 0;
void TIM3_IRQHandler (void) {

 if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET) {                 // check interrupt source
  // LCD_Clear();   
   if ( ypos < 256 ) {
       
     //ADC_VAL[ypos] = 63 - Read_ADC()/86;
     ADC_VAL[ypos] = ADC_GetConversionValue(ADC1);
     //LCD_DrawDot(ADCConvertedValue/86 + 16,ypos );
     ypos++;
   }

   TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
 }
}

void TIM4_IRQHandler (void) {
  
 
 if (TIM_GetITStatus(TIM4, TIM_IT_Update) != RESET) {                 // check interrupt source
  // LCD_Clear();   
   if ( ypos == 256) {       
      uint8_t mid = DSO_Pix_Find_Mid_Pt();
      for ( int i = 0 ; i < 256 ; i ++ )
      {
        if(Source_isAttenuated)
        {
          //Pixel_VAL[i] = (uint16_t)( 63 - (((ADC_VAL[i]+100)/Voltbase_Set[Voltbase_Ptr])- 2048/Voltbase_Set[Voltbase_Ptr] + 23));
          //Pixel_VAL[i] = (uint16_t)( 63 - 5.25*((ADC_VAL[i]+100)/Voltbase_Set[Voltbase_Ptr]- 2048/Voltbase_Set[Voltbase_Ptr]) + 23  ) ;
          Pixel_VAL[i] = (uint16_t)( 63 - ((6*ADC_VAL[i]+550)/Voltbase_Set[Voltbase_Ptr]- 12288/Voltbase_Set[Voltbase_Ptr] + 23)) ;
        }
        else
        {
          Pixel_VAL[i] = (uint16_t)( 63 - (((ADC_VAL[i] + 62)/Voltbase_Set[Voltbase_Ptr])- 2048/Voltbase_Set[Voltbase_Ptr] + 23));
        }
        
         if (Pixel_VAL[i] < 16 || Pixel_VAL[i] > 63 )
           Pixel_VAL[i] = 16;
      }  
     
      
      //Triggering Section
      for ( int i = 0 ; i < 256 ; i ++ )
      {
         if( start_flag == 0 && ((Pixel_VAL[i] >= mid - 1 && Pixel_VAL[i] <= mid + 1) ||
          (Pixel_VAL[i-1]-Pixel_VAL[i] > 1 && Pixel_VAL[i] < mid - 2)) &&
          Pixel_VAL[i-1] >= Pixel_VAL[i] /*&& Pixel_VAL[i] <= Pixel_VAL[i+1]*/  )
         {
            start_flag = i%128;
         }
      }
      
     
     
     LCD_Clear();
     if ( Measurement_Ptr == 0 || Measurement_isSwitched == TRUE || Measurement_Cnt == 10 )
     {
       LCD_ClearHeader();
       DSO_DrawHeader();
       Measurement_isSwitched = FALSE;
     }
     DSO_Draw_Waveform();
     start_flag = 0;
     Measurement_Cnt++;
     if (Measurement_Cnt > 10 )
     {
       Measurement_Cnt = 0;
     }
     
     ypos = 0;
   }
   
   TIM_ClearITPendingBit(TIM4, TIM_IT_Update);
 }
}

void EXTI15_10_IRQHandler(void)
{
  //Middle
    if (EXTI_GetITStatus(EXTI_Line11) != RESET)
    {
        EXTI_ClearITPendingBit(EXTI_Line11); 
        if ( Measurement_Ptr < 4) {
          Measurement_Ptr++;
          Measurement_isSwitched = TRUE;
          //Timebase_Set[Measurement_Ptr];
        }
        else{
          Measurement_Ptr = 0;
        }
    }
  //Right
    if (EXTI_GetITStatus(EXTI_Line12) != RESET)
    {
        EXTI_ClearITPendingBit(EXTI_Line12); 
        if ( Timebase_Ptr > 0) {
          Timebase_Ptr--;
          TIM3->ARR = Timebase_Set[Timebase_Ptr];
        }
    }
    // Left
    if (EXTI_GetITStatus(EXTI_Line13) != RESET)
    {
        EXTI_ClearITPendingBit(EXTI_Line13); 
        if ( Timebase_Ptr < 12) {
          Timebase_Ptr++;
          TIM3->ARR = Timebase_Set[Timebase_Ptr];
        }
    }
    // UP
    if (EXTI_GetITStatus(EXTI_Line14) != RESET)
    {
        EXTI_ClearITPendingBit(EXTI_Line14); 
        if ( Voltbase_Ptr < 7) {
          Voltbase_Ptr++;
        }
    }
    // Down
    if (EXTI_GetITStatus(EXTI_Line15) != RESET)
    {
        EXTI_ClearITPendingBit(EXTI_Line15); 
        if ( Voltbase_Ptr > 0 ) {
          Voltbase_Ptr--;
        }
    }
}


void EXTI9_5_IRQHandler(void)
{

  //PF.6 Attenuation Signal
    if (EXTI_GetITStatus(EXTI_Line6) != RESET)
    {
      
        EXTI_ClearITPendingBit(EXTI_Line6);
        Source_isAttenuated = FALSE;        
    }
    
    if (EXTI_GetITStatus(EXTI_Line7) != RESET)
    {
        EXTI_ClearITPendingBit(EXTI_Line7);  
        Source_isAttenuated = TRUE;
    }
}

/********************************************************* 
 *
 *    DSO Functions
 *
 *********************************************************/


void DSO_Draw_Waveform(void)
{
  
  for(int i = start_flag; i < start_flag + 128; i++)
  {
    LCD_DrawDot(Pixel_VAL[i], i - start_flag);
    if ( i > 0 )
    {
      if ( Pixel_VAL[i] - Pixel_VAL[i-1] > 1 )
      {
         DSO_Fill_Gap(Pixel_VAL[i-1],  Pixel_VAL[i], i - start_flag);
      }else if (Pixel_VAL[i-1] - Pixel_VAL[i] > 1 )
      {
         DSO_Fill_Gap(Pixel_VAL[i], Pixel_VAL[i-1] , i - start_flag);
      }
    }
  }
}

void DSO_Fill_Gap(uint8_t x1, uint8_t x2, uint8_t y)
{
   for(int i = x1 + 1; i < x2; i++){
      LCD_DrawDot(i, y);
   }
}

/* Return the index of MAX(ADC_VAL) starting from offset */
uint8_t DSO_Pix_Find_Max(uint8_t offset)
{
  int max = 63;
  uint8_t max_index = offset;
  for(int i = offset; i< offset +128; i++)
  {
    if (max > Pixel_VAL[i])
    {
      max_index = i;
      max = Pixel_VAL[i];
    }
    
  } 
  return max_index;
}

uint8_t DSO_Pix_Find_Min(uint8_t offset)
{
  int min = 16;
  uint8_t min_index = offset;
  for(int i = offset; i< offset+ 128; i++)
  {
    if (min < Pixel_VAL[i])
    {
      min_index = i;
      min = Pixel_VAL[i];
    }
    
  } 
  return min_index;
}


uint8_t DSO_Pix_Find_Mid_Pt(void)
{
  return ( Pixel_VAL[DSO_Pix_Find_Max(0)] + Pixel_VAL[DSO_Pix_Find_Min(0)] ) /2 ;
  
}


/*******************************************************************************
* Function Name  : DSO_DrawHeader
* Description    : draw the dot grid, 8 horizontal divisions & 6 vertical divisions
* Input          : None
* Output         : None
*******************************************************************************/
void DSO_DrawHeader(void)

{  
  switch (Measurement_Ptr)
  {
    case 0:
        DSO_DrawVoltTime();
        break;
        
    case 1:
        DSO_DrawFT();
        break;
      
    case 2:
        DSO_DrawMinMax();
        break;
      
    case 3:      
        DSO_DrawRMSMean();
        break;
      
    case 4:      
        DSO_DrawPkPk();
        break;
      
    default:      
        DSO_DrawVoltTime();
      
  }
 
}


void DSO_DrawVoltTime(void)
{
 
  int x;
  int fonttime;
 //Create another array in main called Timebase_uS
 if (Timebase_Ptr < 4)

 {
    x = Timebase_uS[Timebase_Ptr];   //50-   500000=|0111|1010|0001|0010|0000|
    fonttime = 117;
 }

 else

 {
    x = Timebase_uS[Timebase_Ptr]/1000;
    fonttime = 109;
 }

 int hundreds = x / 100;
 uint8_t hr = x % 100;
 int tens = hr / 10;
 uint8_t tr = hr % 10;
 int ones = tr;

 LCD_DrawChar(0, 0, 48+hundreds);
 LCD_DrawChar(0, 8, 48+tens);
 LCD_DrawChar(0, 16, 48+ones);
 LCD_DrawChar(0, 24, fonttime);
 LCD_DrawChar(0, 32, 'S');
 //Create another array in main called Voltbase_mV
 
int fontvolt;
 
if (Voltbase_Ptr < 5)

 {
    x = Voltbase_mV[Voltbase_Ptr];
    fontvolt = 109;
 }

 else

 {
    x = Voltbase_mV[Voltbase_Ptr]/1000;
    fontvolt = 0;
 }
 

 hundreds = x / 100;
 hr = x % 100;
 tens = hr / 10;
 tr = hr % 10;
 ones = tr;

 LCD_DrawChar(0, 48, 48+hundreds);
 LCD_DrawChar(0, 56, 48+tens);
 LCD_DrawChar(0, 64, 48+ones);
 LCD_DrawChar(0, 72, fontvolt);
 LCD_DrawChar(0, 80, 'V');
  
  
}


// Hz & uS / mS
void DSO_DrawFT(void)
{
  
 
  uint8_t poff = 0;
  uint8_t foff = 56;
  char output[6];
  uint8_t indexes[3];
  uint8_t max = Pixel_VAL[DSO_Pix_Find_Max(0)];
  uint8_t min = Pixel_VAL[DSO_Pix_Find_Min(0)];
  uint8_t average = (max + min) / 2 ;
  uint8_t index_flag = 0;  
  
  for ( int i = 0; i < 255 ; i++)
  {
    if (  index_flag < 3 && ( ( fabs(Pixel_VAL[i] - average) <= 1 ) || 
        ( Pixel_VAL[i] - Pixel_VAL[i+1] > 3 && Pixel_VAL[i] > average )  || // rising
          ( Pixel_VAL[i+1] - Pixel_VAL[i] > 3 && Pixel_VAL[i] < average ) ) ) // falling
    {
       indexes[index_flag] = i;
       index_flag++;
       i+=3;
    }
  }
  
 
  
  double period = ( indexes[2] - indexes[0] ) * Timebase_uS[Timebase_Ptr]/ 16.8;
  double freq = 1000000/ period;

  // Period
  LCD_DrawChar(0, poff, 'P');
  if (period >= 1000 ) 
  {
  period = period/ 1000 ;   
  sprintf(output,"%f",period);
  
  LCD_DrawString(0, poff+8, (u8*)output, 4);
  LCD_DrawString(0, poff+40, "mS", 2);
    
  } else {
  sprintf(output,"%f",period);
  LCD_DrawString(0, poff+8, (u8*)output, 3);
  LCD_DrawString(0, poff+32, "uS", 2);
  }
  
  // Frequency
  LCD_DrawChar(0, foff, 'F');
  if (freq >= 1000 ) 
  {
  freq = freq/ 1000 ;   
  sprintf(output,"%f",freq);
  
  LCD_DrawString(0, foff+8, (u8*)output, 4);
  LCD_DrawString(0, foff+40, "kHz", 3);
    
  } else {
  sprintf(output,"%f",freq);
  LCD_DrawString(0, foff+8, (u8*)output, 3);
  LCD_DrawString(0, foff+32, "Hz", 2);
  }
  
  

  
}


void DSO_DrawMinMax(void)
{ 

  
  double max_volt;
  double min_volt;

  char output[6];

  int max_val = 0;
  int min_val = 4095;  
  int xoff = 0;
  int noff = 64;
  
  
  for(int i = 0; i< 256; i++)
  {
    if (ADC_VAL[i] < min_val)
    {
      min_val = ADC_VAL[i];
    } 
    if (ADC_VAL[i] > max_val)
    {
      max_val = ADC_VAL[i];
    } 
  } 
  
    if ( Source_isAttenuated ) 
    {
      max_volt = ( (max_val +86 - 2048) /4095.0 ) * 3300 * 6;
    } 
    else 
    {
      max_volt = ( (max_val +43 - 2048) /4095.0 ) * 3300 * 1.08;
    }
  
  
    if ( Source_isAttenuated ) 
    {
      min_volt = ( (min_val +86 - 2048) /4095.0 ) * 3300 * 6;
    } 
    else 
    {
      min_volt = ( (min_val +43 - 2048) /4095.0 ) * 3300 * 1.08;
    }  
  


// MAX 
     
  
    LCD_DrawChar(0, xoff, 'x');
  if (max_volt >= 1000 || max_volt <= -1000 ) 
 {
    max_volt = max_volt/ 1000 ;   
    sprintf(output,"%f",max_volt);
    
    if ( max_volt > 0 )
    {
     LCD_DrawString(0, xoff+8, (u8*)output, 4);
      LCD_DrawChar(0, xoff+40, 'V');
    }  
    else
    {
      LCD_DrawString(0, xoff+8, (u8*)output, 5);
      LCD_DrawChar(0, xoff+48, 'V');
    }
    
    
  } 
  
  else {
    sprintf(output,"%f",max_volt);
    if ( max_volt > 0 )
    {
      LCD_DrawString(0, xoff+8, (u8*)output, 3);
      LCD_DrawString(0, xoff+32, "mV", 2);
    }
    else
    {
      LCD_DrawString(0, xoff+8, (u8*)output, 4);
      LCD_DrawString(0, xoff+40, "mV", 2);
    }

  }
  
  
  // MIN 
   
    LCD_DrawChar(0, noff, 'n');
  if (min_volt >= 1000 || min_volt <= -1000 ) 
  {
    min_volt = min_volt/ 1000 ;   
    sprintf(output,"%f",min_volt);
    
    if ( min_volt > 0 )
    {
      LCD_DrawString(0, noff+8, (u8*)output, 4);
      LCD_DrawChar(0, noff+40, 'V');
    }  
    else
    {
      LCD_DrawString(0, noff+8, (u8*)output, 5);
      LCD_DrawChar(0, noff+48, 'V');
    }
    
    
  } else {
    sprintf(output,"%f",min_volt);
    if ( min_volt > 0 )
    {
      LCD_DrawString(0, noff+8, (u8*)output, 3);
      LCD_DrawString(0, noff+32, "mV", 2);
    }
    else
    {
      LCD_DrawString(0, noff+8, (u8*)output, 4);
      LCD_DrawString(0, noff+40, "mV", 2);
    }

  }  
  
  
}


void DSO_DrawRiseFall(void)
{
  
}


void DSO_DrawRMSMean(void)
{
  int sum = 0;
  unsigned int squaresum = 0;
  double RMS = 0.0;
  double u = 0.0;

  char output[6];
  int funcval;

  
  int RMSoff = 0;
  int uoff = 56;
      
  
  
  for(int i = 0; i< 256; i++)
  {
    if(Source_isAttenuated)
    {
      funcval = (int ) (((ADC_VAL[i]*1.03 + 62   -2048)/4096.0)*3300 * 6 );
      
    }
    else
    {
      funcval = (int ) (((ADC_VAL[i]*1.03 +62 -2048)/4096.0)*3300) ; 
      
    }
      
    sum = sum + funcval;
    
    if ( funcval < 0 ) 
    {
      funcval = (funcval * -1) ;
    }
    
    squaresum = squaresum + (funcval * funcval);
    
  }
  
  RMS = squaresum/256.0;
  RMS = sqrt(RMS);
  
  u = sum/256.0;
  
  
  LCD_DrawChar(0, RMSoff, 'R');
  if (RMS >= 1000 ) 
  {
  RMS = RMS/ 1000 ;   
  sprintf(output,"%f",RMS);
  
  LCD_DrawString(0, RMSoff+8, (u8*)output, 4);
  LCD_DrawChar(0, RMSoff+40, 'V');
    
  } else {
  sprintf(output,"%f",RMS);
  LCD_DrawString(0, RMSoff+8, (u8*)output, 3);
  LCD_DrawString(0, RMSoff+32, "mV", 2);
  }
  
    LCD_DrawChar(0, uoff, 'u');
  if (u >= 1000 || u <= -1000 ) 
  {
  u = u/ 1000 ;   
  sprintf(output,"%f",u);
  
  if ( u > 0 )
  {
    LCD_DrawString(0, uoff+8, (u8*)output, 4);
    LCD_DrawChar(0, uoff+40, 'V');
  }  
  else
  {
    LCD_DrawString(0, uoff+8, (u8*)output, 5);
    LCD_DrawChar(0, uoff+48, 'V');
  }
  
    
  } else {
  sprintf(output,"%f",u);
  if ( u > 0 )
  {
    LCD_DrawString(0, uoff+8, (u8*)output, 3);
    LCD_DrawString(0, uoff+32, "mV", 2);
  }
  else
  {
    LCD_DrawString(0, uoff+8, (u8*)output, 4);
    LCD_DrawString(0, uoff+40, "mV", 2);
  }
  //LCD_DrawString(0, uoff+32, "mV", 2);
  }
  
 
  
  
  
}


void DSO_DrawPkPk(void)
{
 
  
  double max_volt;
  double min_volt;
  double pkpk;
  //u8* mvorv = "mV";
  char output[6];
  int max_val = 0;
  int min_val = 4095;
  
  int xoff = 0;
      //int noff = 64;
  
  
  for(int i = 0; i< 256; i++)
  {
    if (ADC_VAL[i] < min_val)
    {
      min_val = ADC_VAL[i];
    } 
    if (ADC_VAL[i] > max_val)
    {
      max_val = ADC_VAL[i];
    } 
  } 
  
    if ( Source_isAttenuated ) 
    {
      max_volt = ( (max_val - 2048) /4096.0 ) * 3300 * 6;
    } 
    else 
    {
      max_volt = ( (max_val - 2048 ) /4096.0 ) * 3300;
    }
  

  
    if ( Source_isAttenuated ) 
    {
      min_volt = ( (min_val - 2048) /4096.0 ) * 3300 * 6;
    } 
    else 
    {
      min_volt = ( (min_val - 2048) /4096.0 ) * 3300;
    }  

    
    
  pkpk = max_volt-min_volt;
 
   // digit = (uint8_t) floor(log10(pkpk))+1;    
    
  
  LCD_DrawString(0, xoff, "Pk-Pk ", 6);
  if (pkpk >= 1000 ) 
  {
  pkpk = pkpk/ 1000 ;   
  sprintf(output,"%f",pkpk);
  
  LCD_DrawString(0, xoff+48, (u8*)output, 4);
  LCD_DrawChar(0, xoff+80, 'V');
    
  } else {
  sprintf(output,"%f",pkpk);
  LCD_DrawString(0, xoff+48, (u8*)output, 3);
  LCD_DrawString(0, xoff+80, "mV", 2);
    
  }

}



/******************* (C) COPYRIGHT 2009 STMicroelectronics *****END OF FILE****/